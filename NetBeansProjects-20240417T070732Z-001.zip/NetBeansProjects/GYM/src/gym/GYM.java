/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gym;

import Jframe.home;

/**
 *
 * @author SHRUSHANTH
 */
public class GYM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        home h=new home();
    }
    
}
